import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SinhVienForm extends JFrame {
    private JTextField txtMaSV, txtHoTen, txtNgaySinh, txtDiem, txtTimKiem;
    private JComboBox<String> cboGioiTinh, cboMaLop;
    private JTable table;
    private DefaultTableModel model;

    public SinhVienForm() {
        setTitle("Quan Ly Thong Tin Sinh Vien");
        setSize(820, 560);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel nhap lieu
        JPanel pnlInput = new JPanel(new GridLayout(3, 4, 10, 10));
        pnlInput.setBorder(BorderFactory.createTitledBorder("Thong tin chi tiet sinh vien"));

        pnlInput.add(new JLabel("Ma SV:"));
        txtMaSV = new JTextField();
        pnlInput.add(txtMaSV);

        pnlInput.add(new JLabel("Ho Ten:"));
        txtHoTen = new JTextField();
        pnlInput.add(txtHoTen);

        pnlInput.add(new JLabel("Ngay Sinh (YYYY-MM-DD):"));
        txtNgaySinh = new JTextField("2005-01-01");
        pnlInput.add(txtNgaySinh);

        pnlInput.add(new JLabel("Gioi Tinh:"));
        cboGioiTinh = new JComboBox<>(new String[]{"Nam", "Nu"});
        pnlInput.add(cboGioiTinh);

        pnlInput.add(new JLabel("Ma Lop:"));
        cboMaLop = new JComboBox<>();
        pnlInput.add(cboMaLop);

        pnlInput.add(new JLabel("Diem TB:"));
        txtDiem = new JTextField();
        pnlInput.add(txtDiem);

        // Panel Tim kiem & Nut chuc nang
        JPanel pnlAction = new JPanel(new BorderLayout(5, 5));
        JPanel pnlSearch = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlSearch.add(new JLabel("Tim kiem (Ma SV hoac Ho Ten):"));
        txtTimKiem = new JTextField(20);
        JButton btnTim = new JButton("Tim kiem");
        pnlSearch.add(txtTimKiem);
        pnlSearch.add(btnTim);

        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnThem = new JButton("Them");
        JButton btnSua = new JButton("Sua");
        JButton btnXoa = new JButton("Xoa");
        JButton btnLamMoi = new JButton("Lam moi");
        pnlButtons.add(btnThem);
        pnlButtons.add(btnSua);
        pnlButtons.add(btnXoa);
        pnlButtons.add(btnLamMoi);

        pnlAction.add(pnlSearch, BorderLayout.WEST);
        pnlAction.add(pnlButtons, BorderLayout.EAST);

        JPanel pnlTop = new JPanel(new BorderLayout(5, 5));
        pnlTop.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        pnlTop.add(pnlInput, BorderLayout.CENTER);
        pnlTop.add(pnlAction, BorderLayout.SOUTH);
        add(pnlTop, BorderLayout.NORTH);

        // Bang du lieu
        model = new DefaultTableModel(new String[]{"Ma SV", "Ho Ten", "Ngay Sinh", "Gioi Tinh", "Ma Lop", "Diem TB"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        // Su kien chon dong
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaSV.setText(model.getValueAt(row, 0).toString());
                    txtHoTen.setText(model.getValueAt(row, 1).toString());
                    txtNgaySinh.setText(model.getValueAt(row, 2).toString());
                    cboGioiTinh.setSelectedItem(model.getValueAt(row, 3).toString());
                    cboMaLop.setSelectedItem(model.getValueAt(row, 4).toString());
                    txtDiem.setText(model.getValueAt(row, 5).toString());
                    txtMaSV.setEditable(false);
                }
            }
        });

        btnThem.addActionListener(e -> themSV());
        btnSua.addActionListener(e -> suaSV());
        btnXoa.addActionListener(e -> xoaSV());
        btnTim.addActionListener(e -> loadData(txtTimKiem.getText().trim()));
        btnLamMoi.addActionListener(e -> lamMoi());

        loadComboLop();
        loadData("");
    }

    private void loadComboLop() {
        cboMaLop.removeAllItems();
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) return;
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT MaLop FROM LopHoc");
            while (rs.next()) {
                cboMaLop.addItem(rs.getString("MaLop"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadData(String keyword) {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) return;
            String sql = "SELECT * FROM SinhVien WHERE MaSV LIKE ? OR HoTen LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("MaSV"),
                    rs.getString("HoTen"),
                    rs.getString("NgaySinh"),
                    rs.getString("GioiTinh"),
                    rs.getString("MaLop"),
                    rs.getFloat("DiemTB")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void themSV() {
        if (txtMaSV.getText().trim().isEmpty() || txtHoTen.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ma SV va Ho Ten khong duoc de trong!");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaLop, DiemTB) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtMaSV.getText().trim());
            ps.setString(2, txtHoTen.getText().trim());
            ps.setString(3, txtNgaySinh.getText().trim());
            ps.setString(4, cboGioiTinh.getSelectedItem().toString());
            ps.setString(5, cboMaLop.getSelectedItem().toString());
            ps.setFloat(6, Float.parseFloat(txtDiem.getText().trim()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Them sinh vien thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi them sinh vien: " + e.getMessage());
        }
    }

    private void suaSV() {
        if (txtMaSV.isEditable()) {
            JOptionPane.showMessageDialog(this, "Vui long chon sinh vien tren bang de sua!");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE SinhVien SET HoTen=?, NgaySinh=?, GioiTinh=?, MaLop=?, DiemTB=? WHERE MaSV=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtHoTen.getText().trim());
            ps.setString(2, txtNgaySinh.getText().trim());
            ps.setString(3, cboGioiTinh.getSelectedItem().toString());
            ps.setString(4, cboMaLop.getSelectedItem().toString());
            ps.setFloat(5, Float.parseFloat(txtDiem.getText().trim()));
            ps.setString(6, txtMaSV.getText().trim());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Cap nhat thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi cap nhat: " + e.getMessage());
        }
    }

    private void xoaSV() {
        if (txtMaSV.isEditable()) {
            JOptionPane.showMessageDialog(this, "Vui long chon sinh vien tren bang de xoa!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Ban co chac chan muon xoa sinh vien nay?", "Xac nhan", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM SinhVien WHERE MaSV=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtMaSV.getText().trim());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Xoa thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi xoa: " + e.getMessage());
        }
    }

    private void lamMoi() {
        txtMaSV.setText("");
        txtHoTen.setText("");
        txtNgaySinh.setText("2005-01-01");
        txtDiem.setText("");
        txtTimKiem.setText("");
        txtMaSV.setEditable(true);
        loadData("");
    }
}
