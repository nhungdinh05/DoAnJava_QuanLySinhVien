import javax.swing.*;
import java.awt.*;

public class MainForm extends JFrame {
    public MainForm(String username) {
        setTitle("He Thong Quan Ly Dao Tao");
        setSize(500, 320);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 102, 204));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lblWelcome = new JLabel("PHAN MEM QUAN LY SINH VIEN", SwingConstants.CENTER);
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 18));
        lblWelcome.setForeground(Color.WHITE);
        headerPanel.add(lblWelcome, BorderLayout.CENTER);

        JLabel lblUser = new JLabel("Xin chao: " + username, SwingConstants.RIGHT);
        lblUser.setForeground(Color.WHITE);
        headerPanel.add(lblUser, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(25, 40, 25, 40));

        JButton btnQLSV = new JButton("Quan Ly Sinh Vien");
        JButton btnQLLop = new JButton("Quan Ly Lop Hoc");
        JButton btnDoiMK = new JButton("Doi Mat Khau");
        JButton btnDangXuat = new JButton("Dang Xuat");

        Font btnFont = new Font("Arial", Font.BOLD, 13);
        btnQLSV.setFont(btnFont);
        btnQLLop.setFont(btnFont);
        btnDoiMK.setFont(btnFont);
        btnDangXuat.setFont(btnFont);

        menuPanel.add(btnQLSV);
        menuPanel.add(btnQLLop);
        menuPanel.add(btnDoiMK);
        menuPanel.add(btnDangXuat);

        add(menuPanel, BorderLayout.CENTER);

        btnQLSV.addActionListener(e -> new SinhVienForm().setVisible(true));
        btnQLLop.addActionListener(e -> new LopHocForm().setVisible(true));
        btnDoiMK.addActionListener(e -> {
            String newPass = JOptionPane.showInputDialog(this, "Nhap mat khau moi:");
            if (newPass != null && !newPass.trim().isEmpty()) {
                doiMatKhau(username, newPass.trim());
            }
        });
        btnDangXuat.addActionListener(e -> {
            new LoginForm().setVisible(true);
            this.dispose();
        });
    }

    private void doiMatKhau(String user, String newPass) {
        try (java.sql.Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE TaiKhoan SET MatKhau=? WHERE TenDangNhap=?";
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, newPass);
            ps.setString(2, user);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Doi mat khau thanh cong!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Loi doi mat khau: " + ex.getMessage());
        }
    }
}
