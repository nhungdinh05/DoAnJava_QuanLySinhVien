import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LopHocForm extends JFrame {
    private JTextField txtMaLop, txtTenLop, txtKhoa, txtTimKiem;
    private JTable table;
    private DefaultTableModel model;

    public LopHocForm() {
        setTitle("Quan Ly Lop Hoc");
        setSize(680, 480);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel pnlInput = new JPanel(new GridLayout(3, 2, 10, 10));
        pnlInput.setBorder(BorderFactory.createTitledBorder("Thong tin lop hoc"));

        pnlInput.add(new JLabel("Ma Lop:"));
        txtMaLop = new JTextField();
        pnlInput.add(txtMaLop);

        pnlInput.add(new JLabel("Ten Lop:"));
        txtTenLop = new JTextField();
        pnlInput.add(txtTenLop);

        pnlInput.add(new JLabel("Khoa:"));
        txtKhoa = new JTextField();
        pnlInput.add(txtKhoa);

        JPanel pnlAction = new JPanel(new BorderLayout(5, 5));
        JPanel pnlSearch = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlSearch.add(new JLabel("Tim kiem:"));
        txtTimKiem = new JTextField(15);
        JButton btnTim = new JButton("Tim");
        pnlSearch.add(txtTimKiem);
        pnlSearch.add(btnTim);

        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnThem = new JButton("Them");
        JButton btnSua = new JButton("Sua");
        JButton btnXoa = new JButton("Xoa");
        JButton btnLamMoi = new JButton("Lam moi");
        pnlButtons.add(btnThem);
        pnlButtons.add(btnSua);
        pnlButtons.add(btnXoa);
        pnlButtons.add(btnLamMoi);

        pnlAction.add(pnlSearch, BorderLayout.WEST);
        pnlAction.add(pnlButtons, BorderLayout.EAST);

        JPanel pnlTop = new JPanel(new BorderLayout(5, 5));
        pnlTop.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        pnlTop.add(pnlInput, BorderLayout.CENTER);
        pnlTop.add(pnlAction, BorderLayout.SOUTH);
        add(pnlTop, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Ma Lop", "Ten Lop", "Khoa"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaLop.setText(model.getValueAt(row, 0).toString());
                    txtTenLop.setText(model.getValueAt(row, 1).toString());
                    txtKhoa.setText(model.getValueAt(row, 2).toString());
                    txtMaLop.setEditable(false);
                }
            }
        });

        btnThem.addActionListener(e -> themLop());
        btnSua.addActionListener(e -> suaLop());
        btnXoa.addActionListener(e -> xoaLop());
        btnTim.addActionListener(e -> loadData(txtTimKiem.getText().trim()));
        btnLamMoi.addActionListener(e -> lamMoi());

        loadData("");
    }

    private void loadData(String keyword) {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) return;
            String sql = "SELECT * FROM LopHoc WHERE MaLop LIKE ? OR TenLop LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("MaLop"),
                    rs.getString("TenLop"),
                    rs.getString("Khoa")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void themLop() {
        if (txtMaLop.getText().trim().isEmpty() || txtTenLop.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui long nhap Ma Lop va Ten Lop!");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO LopHoc VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtMaLop.getText().trim());
            ps.setString(2, txtTenLop.getText().trim());
            ps.setString(3, txtKhoa.getText().trim());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Them lop thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi: " + e.getMessage());
        }
    }

    private void suaLop() {
        if (txtMaLop.isEditable()) {
            JOptionPane.showMessageDialog(this, "Chon lop tren bang de sua!");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE LopHoc SET TenLop=?, Khoa=? WHERE MaLop=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtTenLop.getText().trim());
            ps.setString(2, txtKhoa.getText().trim());
            ps.setString(3, txtMaLop.getText().trim());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Cap nhat thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi: " + e.getMessage());
        }
    }

    private void xoaLop() {
        if (txtMaLop.isEditable()) {
            JOptionPane.showMessageDialog(this, "Chon lop tren bang de xoa!");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM LopHoc WHERE MaLop=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtMaLop.getText().trim());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Xoa thanh cong!");
            lamMoi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Khong the xoa lop dang co sinh vien!");
        }
    }

    private void lamMoi() {
        txtMaLop.setText("");
        txtTenLop.setText("");
        txtKhoa.setText("");
        txtTimKiem.setText("");
        txtMaLop.setEditable(true);
        loadData("");
    }
}
