CREATE DATABASE QuanLySinhVien;
GO
USE QuanLySinhVien;
GO

-- Bang TaiKhoan (Form 1: Dang nhap)
CREATE TABLE TaiKhoan (
    TenDangNhap VARCHAR(50) PRIMARY KEY,
    MatKhau VARCHAR(50) NOT NULL
);

INSERT INTO TaiKhoan (TenDangNhap, MatKhau) VALUES 
('admin', '123456'),
('user', '123456');
GO

-- Bang LopHoc (Form 4: Quan ly lop hoc - bo sung cho phong phu)
CREATE TABLE LopHoc (
    MaLop VARCHAR(20) PRIMARY KEY,
    TenLop NVARCHAR(100) NOT NULL,
    Khoa NVARCHAR(100) NOT NULL
);

INSERT INTO LopHoc (MaLop, TenLop, Khoa) VALUES
('CNTT1', N'Cong nghe thong tin 1', N'Cong nghe thong tin'),
('CNTT2', N'Cong nghe thong tin 2', N'Cong nghe thong tin'),
('KT1', N'Ke toan doanh nghiep 1', N'Ke toan');
GO

-- Bang SinhVien (Form 3: Quan ly sinh vien)
CREATE TABLE SinhVien (
    MaSV VARCHAR(20) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE,
    GioiTinh NVARCHAR(10),
    MaLop VARCHAR(20) FOREIGN KEY REFERENCES LopHoc(MaLop),
    DiemTB FLOAT
);

INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaLop, DiemTB) VALUES 
('SV01', N'Nguyen Van An', '2005-05-12', N'Nam', 'CNTT1', 8.5),
('SV02', N'Tran Thi Binh', '2005-08-20', N'Nu', 'CNTT2', 7.8),
('SV03', N'Le Hoang Nam', '2005-01-15', N'Nam', 'KT1', 8.2);
GO
