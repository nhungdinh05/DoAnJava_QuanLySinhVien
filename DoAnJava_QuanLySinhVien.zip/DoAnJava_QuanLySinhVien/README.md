# Đồ Án Lập Trình Java - Quản Lý Sinh Viên

## 1. Giới thiệu
Phần mềm Quản lý Sinh viên được xây dựng bằng ngôn ngữ **Java (Java Swing)** kết hợp cơ sở dữ liệu **SQL Server (JDBC)**, đáp ứng đầy đủ các chức năng cơ bản:
- **04 Form giao diện**: Đăng nhập (`LoginForm`), Màn hình chính (`MainForm`), Quản lý Sinh viên (`SinhVienForm`), Quản lý Lớp học (`LopHocForm`).
- **Đầy đủ chức năng CRUD & Tìm kiếm**: Thêm, Sửa, Xóa, Tìm kiếm dữ liệu sinh viên và lớp học trực tiếp trên cơ sở dữ liệu SQL Server.

## 2. Hướng dẫn cài đặt và chạy chương trình
1. **Tạo Cơ sở dữ liệu**:
   - Mở **SQL Server Management Studio (SSMS)**.
   - Mở file `database.sql` trong thư mục dự án và nhấn **Execute (F5)** để tạo database `QuanLySinhVien` cùng dữ liệu mẫu.
2. **Cấu hình kết nối trong Java**:
   - Mở file `src/DatabaseConnection.java`.
   - Sửa biến `PASSWORD` thành mật khẩu tài khoản `sa` trên SQL Server của máy bạn.
   - Thêm thư viện `mssql-jdbc` (file `.jar`) vào thư viện của Project (Libraries / Classpath).
3. **Chạy chương trình**:
   - Chạy file `src/LoginForm.java`.
   - Tài khoản đăng nhập mặc định: `admin` / Mật khẩu: `123456`.
